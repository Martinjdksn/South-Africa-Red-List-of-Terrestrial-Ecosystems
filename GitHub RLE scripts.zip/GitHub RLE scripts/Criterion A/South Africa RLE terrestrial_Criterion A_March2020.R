
#:::::::::::::::::::::::::::::::::::::::::::::::
#  Criteria A: Reduced geographic distribution #
#:::::::::::::::::::::::::::::::::::::::::::::::

library(foreign)

#***********************
# Load key input data  #
#***********************

setwd("C:\\Maphale Monyeki Projects\\ALS Computer\\Terrestrial_RLE_032020\\Raster version\\DBFs")
HabMod<-read.dbf("VM30m_HM60_AEA_TabArea.dbf", TRUE)
#VM<-read.dbf("VEGMAP2018_AEA_V22_7_16082019_Final_MicroestuaryRemvd.dbf",TRUE)

#**************************************************#
#                Start  Processing                 #
#**************************************************#
options(scipen = 999)

names(HabMod)
HabMod<-HabMod[c(6,1:5)]
names(HabMod)[2]<-"Name_18"
names(HabMod)[3]<-"Nat2018"
names(HabMod)[4]<-"Post1990"
names(HabMod)[5]<-"Pre1990"
names(HabMod)[6]<-"Post2014"

attach(HabMod)
HabMod$Nat1750<-(Nat2018+Pre1990+Post1990+Post2014)/1000000
HabMod$Nat1990<-(Nat2018+Post1990+Post2014)/1000000
HabMod$Nat2014<-(Nat2018+Post2014)/1000000
HabMod$Nat2018<-(Nat2018)/1000000

HabMod$Pre1990<-Pre1990/1000000
HabMod$Post1990<-Post1990/1000000
HabMod$Post2014<-Post2014/1000000

names(HabMod)
HabMod<-HabMod[c(1,2,7:9,3,5,4,6)]

#***************************************
# Calculation of the rates of decline  #         
#***************************************

#Calculate absolute rate of decline (ARD) between 1990 and 2018
HabMod$ARD.90_18<-(-(HabMod$Nat2018-HabMod$Nat1990)/(2018-1990))

# Estimate area of ecosystem natural and lost between 1990 and 2040 (ARD.90_18) 
HabMod$Nat2040ARD.90_18<-HabMod$Nat1990-(HabMod$ARD.90_18*50)

# percentage Natural 
options(scipen = 999)
HabMod$PrcNat.2018<-round((HabMod$Nat2018/HabMod$Nat1750)*100,0)
HabMod$PrcLost.2018<-round((HabMod$Nat1750-HabMod$Nat2018)/HabMod$Nat1750*100,0)
HabMod$PrcNat2040ARD<-round((HabMod$Nat2040ARD.90_18/HabMod$Nat1990)*100,0)
HabMod$PrcLost2040ARD<-round(((HabMod$Nat1990-HabMod$Nat2040ARD.90_18)/HabMod$Nat1990)*100,0)

#************************
#  Threat/risk status   #
#************************
HabMod$A2b<-ifelse(HabMod$PrcLost2040ARD>=80, "CR",
                 ifelse(HabMod$PrcLost2040ARD>=50,"EN",
                        ifelse(HabMod$PrcLost2040ARD>=30, "VU","LC")))

# percentage of natural extent lost
HabMod$A3<-ifelse(HabMod$PrcLost.2018>=90,"CR",
                ifelse(HabMod$PrcLost.2018>=70,"EN",
                       ifelse(HabMod$PrcLost.2018>=50, "VU","LC")))

#*****************************************
#  Ranking the threat status Criteria    #
#*****************************************

HabMod$"A2b Basis"<-ifelse(HabMod$A2b=="CR",4, 
                          ifelse(HabMod$A2b=="EN",3, 
                                ifelse(HabMod$A2b=="VU",2,1)))

HabMod$"A3 Basis"<-ifelse(HabMod$A3=="CR",4, 
                         ifelse(HabMod$A3=="EN",3, 
                               ifelse(HabMod$A3=="VU",2,1)))

HabMod$"A2b_A3 Basis"<-pmax(HabMod$"A2b Basis",HabMod$"A3 Basis",na.rm = T)

HabMod$"Criterion A"<-ifelse(HabMod$"A2b_A3 Basis"==4, "CR",
                             ifelse(HabMod$"A2b_A3 Basis"==3,"EN",
                                   ifelse(HabMod$"A2b_A3 Basis"==2, "VU","LC")))


# remove non-terrestrial ecosystem types
Data <- HabMod[-c(261:267),]

write.csv(Data,"C:\\Maphale Monyeki Projects\\ALS Computer\\Terrestrial_RLE_032020\\Raster version\\R results\\South Africa RLE_criterion A March2020.csv")


!!! Done














