
#::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
#  Criterion A3 & D3_ALT (using supplementary data from provinces and cities)     #
#                 to estimate historic declines and degradation                   #
#::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::


library(foreign)

#***********************
# Load key input data  #
#***********************

setwd("C:\\Maphale Monyeki Projects\\ALS Computer\\Terrestrial_RLE_032020\\Raster version\\DBFs")
ALT<-read.dbf("VM30m_HM60_L1_ALT_A3_Deg_TabArea.dbf")


#**************************************************#
#                Start  Processing                 #
#**************************************************#

names(ALT)[1]<-"Name_18"

ALT$"NatAlt 2018"<-ALT$HM60__0/1000000    # Natural extent based on supplementary data
ALT$"LostAlt 2018"<-ALT$HM60__1/1000000   # Natural extent lost based on supplementary data
ALT$"DegAlt 2018"<-ALT$HM60__2/1000000    # Degraded extent based on supplementary data

#*****************************************
# Calculation of natural habitat change  #         
#*****************************************

ALT$"PrcLost Alt"<-round((ALT$"LostAlt 2018")/(ALT$"NatAlt 2018"+ALT$"LostAlt 2018"+ALT$"DegAlt 2018")*100,0)
ALT$"PrcDegLost Alt"<-round((ALT$"LostAlt 2018"+ALT$"DegAlt 2018")/(ALT$"NatAlt 2018"+ALT$"LostAlt 2018"+ALT$"DegAlt 2018")*100,0)

#************************
#  Threat/risk status   #
#************************

ALT$"A3 Alt"<-ifelse(ALT$"PrcLost Alt">=90, "CR",
                    ifelse(ALT$"PrcLost Alt">=70,"EN",
                           ifelse(ALT$"PrcLost Alt">=50, "VU","LC")))

ALT$"D3 Alt"<-ifelse(ALT$"PrcDegLost Alt">=90,"EN",
                   ifelse(ALT$"PrcDegLost Alt">=70, "VU","LC"))

table(ALT$"D3 Alt")
table(ALT$"A3 Alt")

names(ALT)
Data<-ALT[-c(261:267),-c(2:4)]

#**********************************************************************
#********        Ranking the threat status Criteria         ***********
#**********************************************************************

Data$"A3Alt Basis"<-ifelse(Data$"A3 Alt"=="CR",4,
                        ifelse(Data$"A3 Alt"=="EN",3,
                             ifelse(Data$"A3 Alt"=="VU",2,1)))

Data$"D3Alt Basis"<-ifelse(Data$"D3 Alt"=="CR",4,
                           ifelse(Data$"D3 Alt"=="EN",3,
                                 ifelse(Data$"D3 Alt"=="VU",2,1)))


Data$"A3_D3 Alt Basis"<-pmax(Data$"A3Alt Basis",Data$"D3Alt Basis",na.rm = T)

Data$"A3_D3 Alt"<-ifelse(Data$"A3_D3 Alt Basis"==4, "CR",
                      ifelse(Data$"A3_D3 Alt Basis"==3,"EN",
                             ifelse(Data$"A3_D3 Alt Basis"==2, "VU","LC")))

write.csv(Data,"C:\\Maphale Monyeki Projects\\ALS Computer\\Terrestrial_RLE_032020\\Raster version\\R results\\South Africa RLE supplementary assessment_criterion A3 & D3_ March2020.csv")

