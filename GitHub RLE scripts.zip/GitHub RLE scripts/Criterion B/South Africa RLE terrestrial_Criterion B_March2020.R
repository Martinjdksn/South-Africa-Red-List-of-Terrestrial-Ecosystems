#:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
# Criteria B: Restricted distribution & continuing declines in geographic distribution #
#:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

install.packages(c("sp","raster", "maptools", "rgdal", "stringr", "redlistr", "foreign", "plyr"))

library(sp)
library(raster)
library(maptools)
library(rgdal)
library(stringr)
library(redlistr)
library(plyr)
library(foreign)

ecosystem.data = raster("C:\\Maphale Monyeki Projects\\ALS Computer\\Terrestrial_RLE_032020\\Mxd\RLE_032020\\commondata\\Remn_120m.tif")
 
#summary(ecosystem.data)
projection(ecosystem.data)
plot(ecosystem.data)


NAvalue(ecosystem.data) <- 0
filename  = filename(ecosystem.data)
isLonLat(ecosystem.data) # if true --> need to change to a projected coordinate system
#sr <- "+proj=utm +zone=54 +south +datum=WGS84 +units=m +no_defs +ellps=WGS84 +towgs84=0,0,0"  # reproject to UTM
#ecosystem.data <- projectRaster(ecosystem.data, crs = sr,   method = "ngb") 
# use nearest neigbour (ngb) to preserve class values rather than default (bilinear)
inRast = ecosystem.data
grid.size = 10000

# set up data capture
results.df <- data.frame (
  in.raster = NA,
  eco.class = NA,
  grid.size = NA,
  eco.area.km2 = NA,
  #eco.grain = NA,
  eoo.area.km2 = NA,
  eoo.size.status = NA,
  aoo.occ = NA,
  aoo.1pc = NA,
  aoo.status = NA,
  B1B2.overall = NA,
  start.time = NA)


# start on the multiclass raster
vALS_Basis = freq(inRast, useNA = "no") # get class values from raster
valList = vALS_Basis[,1] # convert list of values
message('Raster has >>> ', length(valList) , ' <<< classes' )


for (i in valList){
  message ("working on class... ", i)
  start.time = Sys.time()
  rast <- inRast == i
  values(rast)[values(rast) == 0] <- NA
  eco.area.km2 <- getArea(rast)
  message (paste("... area of ecosystem is", eco.area.km2, "km^2"))
  #eco.grain <- getCellWidth(rast) #cannot find this function in R
  eoo.shp = makeEOO(rast)
  eoo.area.km2 = getAreaEOO(eoo.shp)
  message (paste("... area of EOO is", eoo.area.km2, "km^2"))
  occ.no = getAOO(rast,  10000, FALS_BasisE)
  message (paste("... number of occupied grid cells is", occ.no, "10 x 10-km cells"))
  aoo.1pc = getAOO(rast,  10000, TRUE)
  message (paste("... number of AOO 1% grid cells is", aoo.1pc, "10 x 10-km cells"))
  
  #assess criteria
  if (eoo.area.km2 == 0){ # if 0 it means no ecosystem exists
    eoo.size.status <- "CO"
  } else if (eoo.area.km2 > 0 & eoo.area.km2 <= 2000){
    eoo.size.status <- "CR"
  } else if (eoo.area.km2 > 2000 & eoo.area.km2 <= 20000){
    eoo.size.status <- "EN"
  } else if (eoo.area.km2 > 20000 & eoo.area.km2 <= 50000){
    eoo.size.status <- "VU"
  } else {
    eoo.size.status <- "LC"
  }
  
  # aoo
  if (aoo.1pc <= 2){  # if 0 cells then it is CR, rather than CO due to the 1pc rule
    aoo.size.status <- "CR"
  } else if (aoo.1pc > 2 & aoo.1pc <= 20){
    aoo.size.status <- "EN"
  } else if (aoo.1pc > 20 & aoo.1pc <= 50){
    aoo.size.status <- "VU"
  } else {
    aoo.size.status <- "LC"
  }
  
  combo.status <- paste0(aoo.size.status, eoo.size.status)
  
  if (str_detect(combo.status,"CO") == TRUE) {
    B1B2.size.overall = "CO"
  } else if (str_detect(combo.status,"CR") == TRUE) {
    B1B2.size.overall = "CR"
  } else if (str_detect(combo.status,"EN") == TRUE) {
    B1B2.size.overall = "EN"
  } else if (str_detect(combo.status,"VU") == TRUE) {
    B1B2.size.overall = "VU"
  } else {
    B1B2.size.overall = "LC"
  }
  
  ecoclass.df <- data.frame (
    in.raster = filename,
    eco.class = i,
    grid.size = grid.size,
    eco.area.km2 = eco.area.km2,
    #eco.grain = eco.grain,
    eoo.area.km2 = eoo.area.km2,
    eoo.status = eoo.size.status,
    aoo.occ = occ.no,
    aoo.1pc = aoo.1pc,
    aoo.status = aoo.size.status,
    B1B2.size.overall = B1B2.size.overall,
    start.time = start.time )
  
  results.df <- rbind(results.df, ecoclass.df)
  rm (ecoclass.df,rast, i, eco.area.km2, eoo.area.km2,
      eoo.size.status, occ.no, aoo.1pc, aoo.size.status, B1B2.size.overall, start.time)
  do.call(file.remove,list(list.files(pattern=".gr*")))  # explicitly delete temp files
}

message ("Analysis complete.")
## Writing results to scratch

write.csv(results.df, "C:\\GIS_MAPHALE\\Maphale Monyeki\\RLE\\Terrestrial_RLE_032020\\Raster version\\R results\\Results_Nick_VegMap2018_16082019.csv")

#**********************#
# Load key csv & dbfs  #
#**********************#

setwd("C:\\Maphale Monyeki Projects\\ALS Computer\\Terrestrial_RLE_032020\\Raster version\\DBFs")
Results<-read.csv("Results_Nick_VegMap2018_16082019.csv", TRUE)

setwd("C:\\Maphale Monyeki Projects\\ALS Computer\\Terrestrial_RLE_032020\\Raster version\\DBFs")
HabMod<-read.dbf("VM30m_HM60_AEA_TabArea.dbf", TRUE)
Remnt_Extent120m<-read.dbf("VM120m_rasterValues.dbf", TRUE)
VM<-read.dbf("VEGMAP2018_AEA_V22_7_16082019_Final_MicroestuaryRemvd.dbf",TRUE)

#**************************************************#
#                Start  Processing                 #
#**************************************************#

names(Results)
#Dropping rows and rearranging columns
Results <- Results[-c(1),c(3,5:11) ]

#Rename coulumns
names(Results)[1]<-"Value" 
names(Results)[2]<-"Eco.km2.2018" 
names(Results)[3]<-"EOO.area.km2.2018"
names(Results)[5]<-"AOO.occ.2018"
names(Results)[6]<-"AOO.1pc.2018"
names(Remnt_Extent120m)[1]<-"Value"
names(Remnt_Extent120m)[3]<-"Name_18"

# order the unique values (eco class) by ascending order
Results<-Results[order(Results[,1]),]

# dbf of the raster 
Remnt<-merge(Remnt_Extent120m,Results, "Value")
head(Remnt)

#*****************************************************************************************************#
# read the dbf flile (Remnt_Extent120m:the dbf version of the raster file used in Nick's code)        #                                      
# the purpose is to merge the results from nick with the dbf of the vegmap raster file ()             #
#                                                                                                     #
#*****************************************************************************************************#
names(HabMod)
HabMod<-HabMod[c(6,1:5)]
names(HabMod)[2]<-"Name_18"
names(HabMod)[3]<-"Nat2018"
names(HabMod)[4]<-"Post1990"
names(HabMod)[5]<-"Pre1990"
names(HabMod)[6]<-"Post2014"

attach(HabMod)
HabMod$Nat1750<-(Nat2018+Pre1990+Post1990+Post2014)/1000000
HabMod$Nat1990<-(Nat2018+Post1990+Post2014)/1000000
HabMod$Nat2014<-(Nat2018+Post2014)/1000000
HabMod$Nat2018<-(Nat2018)/1000000

HabMod$Pre1990<-Pre1990/1000000
HabMod$Post1990<-Post1990/1000000
HabMod$Post2014<-Post2014/1000000

names(HabMod)
HabMod<-HabMod[c(1,2,7:9,3,5,4,6)]

#**********************************************************************
#*****    Identifying ecosystems with ongoing rates of declines   *****
#**********************************************************************
options(scipen = 999)

Data<-merge(HabMod,Remnt, "Name_18", all = TRUE)

# Qualifier per year: percentage of loss per year from 1990 to 2018 (28 years)
Data$AnnulDeclYr90_18<-((Data$Nat1990-Data$Nat2018)/Data$Nat1990)/28*100
Data$PrcAnnulDeclYr90_18<-round(Data$AnnulDeclYr90_18,1)
Data$Status90_18<-ifelse(Data$PrcAnnulDeclYr90_18< 0.4,"Stable","Decline")

names(Data)
Data<-Data[c(2,11,1,3:6,12,7:9,13,15,16,14,17:21)]

#****************************************************************#
#*****   Overall threat/risk status per sub-criterion       *****#
#*#**************************************************************#

Data$B1i<-ifelse(Data$Status90_18=="Stable","LC",
                      as.character(Data$eoo.status))

Data$B2i<-ifelse(Data$Status90_18=="Stable","LC",
                      as.character(Data$aoo.status))

table(Data$B1i)
table(Data$B2i)
#***********************************************************#
#*****   Overall threat/risk status for criterion B    *****#
#*#*********************************************************#
Data$"B1i Basis"<-ifelse(Data$B1i=="CR",4,
                         ifelse(Data$B1i=="EN",3,
                                ifelse(Data$B1i=="VU",2,1)))

Data$"B2i Basis"<-ifelse(Data$B2i=="CR",4,
                             ifelse(Data$B2i=="EN",3,
                                    ifelse(Data$B2i=="VU",2,1)))

Data$"B1i_B2i Basis"<-pmax(Data$"B1i Basis",Data$"B2i Basis",na.rm = T)

Data$"Criterion B"<-ifelse(Data$"B1i_B2i Basis"==4, "CR",
                       ifelse(Data$"B1i_B2i Basis"==3,"EN",
                              ifelse(Data$"B1i_B2i Basis"==2, "VU","LC")))

# remove non-terrestrial ecosystem types
Dat <- Data[-c(261:267),]

write.csv(Dat,"C:\\Maphale Monyeki Projects\\ALS Computer\\Terrestrial_RLE_032020\\Raster version\\R results\\South Africa RLE_criterion B March2020.csv")

!!! Done